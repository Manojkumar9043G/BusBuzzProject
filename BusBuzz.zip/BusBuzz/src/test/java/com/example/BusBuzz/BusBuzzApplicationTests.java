package com.example.BusBuzz;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BusBuzzApplicationTests {

	@Test
	void contextLoads() {
	}

}
